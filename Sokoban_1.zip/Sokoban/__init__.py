#PLOUVIN Patrice, NEUMAN Marine, GUEVORTE Flavien
#Date :
#La documentation du projet

'''
Titre du jeu : Sokoban


Noms des auteurs et leurs adresses email :
NEUMAN Marine : marine_neuman@ens.univ-artois.fr 
PLOUVIN Patrice : patrice_plouvin@ens.univ-artois.fr 
GUEVORTE Flavien : flavien_guevorte@ens.univ-artois.fr 


Date de création.
27/11/2017


Discipline : Algorithme et programmation 1


Institution : Université d’Artois


Description du jeu :
    Objectif (pour gagner):
    Déplacer les boites pour les amener à un endroit précis par l'intermédiaire
    d'un personnage


    Règles du jeu et le contrôle du personnage:
'''
#finir regle
