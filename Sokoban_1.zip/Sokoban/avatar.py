#PLOUVIN Patrice, NEUMAN Marine, GUEVORTE Flavien
#Date :
#L’implémentation de l’avatar du joueur
