#PLOUVIN Patrice NEUMAN Marine GUEVORT Flavien
#Date :  29/11/2017
#L’implémentation des scénarios (niveaux du jeu)


#Import de Pygame
import pygame

#Autres import
from couleur import *

#Constante
T_GRILLE = 30
QUITTER = 0         # Quitter le jeu.
RECOMMENCER = 1     # Recommencer le scénario.
CONTINUER = 2       # Continue.

#Légende:

# Symboles pour le scénario.
DEST   = '.'   # Destination     
BOITE  = '$'   # Caisse          
MUR    = '#'   # Mur             
PERSO  = '@'   # Personnage      
VIDE   = ' '

GRILLES = ['''
#######
#@$  .#
#######
''',
'''
     #####
     #   #
     #$  #
   ###  $##
   #  $ $ #
#### # ## #   #######
#    # ## #####   ..#
# $   $           ..#
###### #### #@##  ..#
     #      #########
     ########''',
'''
############
#..  #     ###
#..  # $  $  #
#..  #$####  #
#..    @ ##  #
#..  # #  $ ##
###### ##$ $ #
  # $  $ $ $ #
  #    #     #
  ############
''',
'''
  #####
###   #
#.@$  #
### $.#
#.##$ #
# # . #
#$  $$.#
#   .  #
########'''
]

#Initialisation
def init(num):
    '''Fonction qui initialise un niveau
       Argument : int
       Retour : dict'''
    #Dictionnaire des attributs du scénario
    att={}
    
    #L’avatar du joueur (défini plus tard)
    att['joueur'] = None
    
    #La liste de caisses du scénario (définie plus tard)
    att['caisses'] = []
    
    #une liste de listes de caractères.
    #Le caractère (i,j) de la grille doit correspondre
    #à un objet immobile du scénario (murs et destinations)
    att['grille'] = []
    att['grille'].append([])
    l = 0
    c = 0
    for i in GRILLES[num]:
        if i == '\n':
            att['grille'].append([])
            l += 1
            c = 0
        else:
            # Mur ou Destination:
            if i == MUR or i == DEST:
                att['grille'][l].append(i)
            else:
                att['grille'][l].append(' ')
            c += 1
    return att



def dessine(surface, scen):
    '''Dessine le scénario.
       Arguments : surface, dict
       Retour : None'''
    surface.fill(NOIR)
    # Dessine la grille.
    l = 0
    for i in scen['grille']:
        c = 0
        for j in i:
            if j == MUR:
                dessine_mur(surface, l, c)
            elif j == DEST:
                dessine_cible(surface, l, c)
            c += 1
        l += 1



def dessine_mur(surface, l, c):
    '''Fonction qui dessine les murs
       Argument : surface, int, int
       Retour : None'''
    pygame.draw.rect(surface, GRIS, (c*T_GRILLE, l*T_GRILLE, T_GRILLE, T_GRILLE))



def dessine_cible(surface, l, c):
    '''Fonction qui dessine les cibles
       Argument : surface, int, int
       Retour : None'''
    pygame.draw.line(surface, BLANC, (c*T_GRILLE+2, l*T_GRILLE+2), (c*T_GRILLE+T_GRILLE-4, l*T_GRILLE+T_GRILLE-4), 2)
    pygame.draw.line(surface, BLANC, (c*T_GRILLE+T_GRILLE-4, l*T_GRILLE+2),(c*T_GRILLE+2, l*T_GRILLE+T_GRILLE-4), 2)



def traite_evt(scen):
    '''Traite les évènements.
       Arguments : dict
       Retour : int'''
    # Pour chaque évènement:
    for event in pygame.event.get():

        #L'utilisateur choisi de quitter
        if event.type == pygame.QUIT:
            return QUITTER

        # Si une touche est appuyée:    
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return QUITTER
            if event.key == pygame.K_r:
                return RECOMMENCER
            if event.key == pygame.K_RETURN:
                return CONTINUER
    return CONTINUER


def execute(scen):
    '''Exécute le scénario.
       Arguments : dict 
       Retour : int'''
    # Initialise l'horloge.
    horloge = pygame.time.Clock()
    
    # Boucle principale du scénario:
    res = CONTINUER
    terminer = False
    while not terminer:
        
        # Traite les évènements.
        res = traite_evt(scen)

        # Si le joueur a décidé de quitter:
        if res == QUITTER:
            terminer = True

        # Dessine le scénario.
        surface = pygame.display.get_surface()
        dessine(surface, scen)

        # Met à jour l'écran.
        pygame.display.update()

        # Actualise l'horloge.
        horloge.tick(30)

    return res






    
