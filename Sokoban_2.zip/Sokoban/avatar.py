#PLOUVIN Patrice, NEUMAN Marine, GUEVORTE Flavien
#Date :
#L’implémentation de l’avatar du joueur


#Import de Pygame
import pygame

#Autres import
import scenario
from couleur import *

#Initialisation
def init(l, c, d):
    '''Fonction qui initialise l'avatar
       Argument : int int int
       Retour : dict'''
    #Dictionnaire
    att={}

    #Ligne où se trouve l’avatar
    att['pos_l'] = l
    
    #Colonne où se trouve l’avatar
    att['pos_c'] = c

    #Direction
    #Ou il regarde 0 = haut, 1 = droite, 2 = bas et 3 = gauche
    att['direc'] = d

    #Vitesse de déplacement ligne
    att['vit_l'] = 1

    #Vitesse de déplacement colonne
    att['vit_c'] = 1

    return att


#Dessin avatar
def dessine(att, surface):
    '''Fonction qui dessine le personnage
       Argument : dict, surface
       Retour : None'''
    pygame.draw.rect(surface, BLANC, (30*att['pos_c']+10, 30*att['pos_l']+10, 10, 10))
    
#Mise à jour de l'avatar
def update(scen):
    '''Fonction qui met a jour le scénario
       Argument : dict
       Retour : None'''
    scen = scenario.avatar_evt(scen)














    
