#PLOUVIN Patrice NEUMAN Marine GUEVORTE Flavien
#Date :  29/11/2017
#L’implémentation des scénarios (niveaux du jeu)


#Import de Pygame
import pygame

#Autres import
from couleur import *
import grilles
import avatar
import caisse

#Constante
T_GRILLE = 30
QUITTER = 0         # Quitter le jeu.
RECOMMENCER = 1     # Recommencer le scénario.
CONTINUER = 2       # Continue.

#Légende:
DEST   = '.'   # Destination     
BOITE  = '$'   # Caisse          
MUR    = '#'   # Mur             
PERSO  = '@'   # Personnage      
VIDE   = ' '


#Initialisation
def init(num):
    '''Fonction qui initialise un niveau
       Argument : int
       Retour : dict'''
    #Dictionnaire des attributs du scénario
    att={}
    
    #L’avatar du joueur       
    att['joueur'] = None
    
    #La liste de caisses du scénario (définie plus tard)
    liste_caisses = []
    att['caisses'] = liste_caisses
    
    #une liste de listes de caractères.
    #Le caractère (i,j) de la grille doit correspondre
    #à un objet immobile du scénario (murs et destinations)
    att['grille'] = []
    att['grille'].append([])
    l = 0
    c = 0
    for elements in grilles.GRILLES[num]:
        if elements == '\n':
            att['grille'].append([])
            l += 1
            c = 0
        else:
            # Mur ou Destination:
            if elements == MUR or elements == DEST:
                att['grille'][l].append(elements)
            #Personnage
            elif elements == PERSO:
                att['grille'][l].append(elements)
                att['joueur']=avatar.init(l, c, 0)
            #Caise
            elif elements == BOITE:
                att['grille'][l].append(elements)
                ca = caisse.init(l, c)
                liste_caisses += [ca]                
            #Si c'est vide
            else:
                att['grille'][l].append(' ')
            c += 1
            
    #La liste de caisses du scénario (définie plus tard)
    att['caisses'] = liste_caisses
    
    return att



def dessine(surface, scen):
    '''Dessine le scénario.
       Arguments : surface, dict
       Retour : None'''
    # Reset de l'écrant
    surface.fill(NOIR)
    # Dessine la grille.
    l = 0
    #Pour chaque elements dans la grille
    for elem in scen['grille']:
        c = 0
        for j in elem:
            #Dessiner un mur
            if j == MUR:
                dessine_mur(surface, l, c)
            #Dessiner une cible
            elif j == DEST:
                dessine_cible(surface, l, c)
            #Dessiner une boite
            elif j == BOITE:
                for boite in range(len(scen['caisses'])):
                    caisse.dessine(scen['caisses'][boite], surface)
            #Dessiner le personnage
            elif j == PERSO:
                avatar.dessine(scen['joueur'], surface)
            c += 1
        l += 1



def dessine_mur(surface, l, c):
    '''Fonction qui dessine les murs
       Argument : surface, int, int
       Retour : None'''
    pygame.draw.rect(surface, MARRON, (c*T_GRILLE, l*T_GRILLE, T_GRILLE, T_GRILLE))



def dessine_cible(surface, l, c):
    '''Fonction qui dessine les cibles
       Argument : surface, int, int
       Retour : None'''
    pygame.draw.line(surface, GRIS, (c*T_GRILLE+2, l*T_GRILLE+2), (c*T_GRILLE+T_GRILLE-4, l*T_GRILLE+T_GRILLE-4), 2)
    pygame.draw.line(surface, GRIS, (c*T_GRILLE+T_GRILLE-4, l*T_GRILLE+2),(c*T_GRILLE+2, l*T_GRILLE+T_GRILLE-4), 2)



def traite_evt(scen):
    '''Traite les évènements.
       Arguments : dict
       Retour : int'''
    # Pour chaque évènement:
    for event in pygame.event.get():

        #L'utilisateur choisi de quitter
        if event.type == pygame.QUIT:
            return QUITTER

        # Si une touche est appuyée:    
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return QUITTER
            if event.key == pygame.K_r:
                return RECOMMENCER
            if event.key == pygame.K_RETURN:
                return CONTINUER
    return CONTINUER

def avatar_evt(scen):
    '''Fonction qui traite le déplacement
       Argument : dict
       Retour : int'''
    # Pour chaque évènement:
    for event in pygame.event.get():

        # Si une touche est appuyée:    
        if event.type == pygame.KEYDOWN:
            #Flèche gauche
            if event.key == pygame.K_LEFT:
                scen['pos_c']-=scen['vit_l']
                scen['direc'] = 3
            #Flèche droite
            if event.key == pygame.K_RIGHT:
                scen['pos_c']+=scen['vit_l']
                scen['direc'] = 1
            #Flèche haut
            if event.key == pygame.K_UP:
                scen['pos_l']-=scen['vit_c']
                scen['direc'] = 0
            #Flèche bas
            if event.key == pygame.K_DOWN:
                scen['pos_l']+=scen['vit_c']
                scen['direc'] = 2
    return scen

   

def execute(scen):
    '''Exécute le scénario.
       Arguments : dict 
       Retour : int'''
    # Initialise l'horloge.
    horloge = pygame.time.Clock()
    
    # Boucle principale du scénario:
    res = CONTINUER
    terminer = False
    while not terminer:
        
        #Faire bouger l'avatar
        avatar.update(scen['joueur'])
        
        # Traite les évènements.
        res = traite_evt(scen)
        
        # Si le joueur a décidé de quitter:
        if res == QUITTER:
            terminer = True
            
        #avatar.update(scen['joueur'])
            
        # Dessine le scénario.
        surface = pygame.display.get_surface()
        dessine(surface, scen)

        # Met à jour l'écran.
        pygame.display.update()

        # Actualise l'horloge.
        horloge.tick(30)


    return res






    
